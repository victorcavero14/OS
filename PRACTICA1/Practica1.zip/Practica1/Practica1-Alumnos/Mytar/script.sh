#!/bin/bash
if [ -f mytar ] && [ -x mytar ]; then
	echo "El programa Mytar existe y está listo para ejecutarse :) "
    if [ -d tmp ]; then
        rm -rf tmp
    fi
 else
 echo "El programa Mytar no existe. Cerrando..."
fi

mkdir tmp
cd tmp

echo "Hello world!" > file1.txt
head -n 10 /etc/passwd > file2.txt
head -c 1024 /dev/urandom > file3.dat

../mytar -c -f filetar.mtar file1.txt file2.txt file3.dat
mkdir out 
cp filetar.mtar out/
cd out

../../mytar -x -f ../filetar.mtar

diff file1.txt ../file1.txt && diff file2.txt ../file2.txt && diff file3.dat ../file3.dat
if [ $? -eq 0 ]; then
   cd ../..
   echo "Correct"
else 
   cd ../..
   echo "Different files,try again"
fi
